package com.og.app.gui.listener;

public interface WebImageListener
{
        public abstract void webImageReady();
} 
