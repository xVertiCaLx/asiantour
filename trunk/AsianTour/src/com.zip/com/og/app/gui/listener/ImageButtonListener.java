package com.og.app.gui.listener;

public interface ImageButtonListener
{
        public abstract void imageButtonClicked(int id);
        public abstract void imageButtonOnFocus(int id);
        public abstract void imageButtonOnUnfocus(int id);
        
} 
