package com.og.app.gui.listener;

public interface ListFieldListener
{
        public abstract void onListFieldUnfocus();
        public abstract boolean isListFieldFocus();
} 
