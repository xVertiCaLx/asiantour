package com.og.app.gui;

import com.og.app.object.*;
import com.og.app.gui.listener.*;
import com.og.app.gui.component.*;
import com.og.app.*;
import com.og.app.util.*;
import com.og.rss.*;

import net.rim.device.api.system.Characters;
import net.rim.device.api.ui.Manager;
import net.rim.device.api.ui.component.ListField;
import net.rim.device.api.ui.component.ListFieldCallback;
import net.rim.device.api.system.*;
import net.rim.device.api.ui.*;

import javax.microedition.io.*;

import java.util.*;
import java.io.*;

public class NewsListField extends CustomListField {
    private NewsPanel newsPanel = null;
    private String feedname = "";
    
    public NewsListField(NewsPanel newsPanel, ListFieldListener listener) {
        super(listener);
        this.newsPanel = newsPanel;
    }
    
    protected void onFocus(int direction) {
        newsPanel.invalidate();
    }
    
    protected synchronized boolean navigationMovement(int dx, int dy, int status, int time) {
        if (dy < 0) {
            int tmpy = dy*-1;
            if (getSelectedIndex() > 0) {
                do {
                    setSelectedIndex(getSelectedIndex()-1);
                } while(tmpy > 0);
            }
            
            listener.onListFieldUnfocus();
            newsPanel.invalidate();
            return true;
        }
        
        newsPanel.invalidate();
        return false;
    }
    
    public boolean navigationClick(int status, int time) {
        if (getSize() > 0) {
            //bring to news details
            return true;
        }
        
        return false;
    }
    
    public void loadNews(int newsID) {
        setRowHeight();
        ANewsItemObj[] item = new ANewsItemObj[5];
        
        synchronized(lock) {
            this.newsID = newsID;
            
            removeAll();
            for (int i = 0; i < 5; i++) {
                item[i] = new ANewsItemObj("Test news "+i, "Aloysius Ong", "5mins ago", "Some very long description or news content that must store more than 50 characters in order to try and let it show the triple dots which we have created earlier. So folks, this is news " + i + ".", "1");
                add(item[i]);
            }
            
        }
    }
    
}
