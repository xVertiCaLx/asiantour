package com.og.app.asiantour;

public class ACategoryObj implements net.rim.device.api.util.Persistable {
    public int id=-1;
    public String title = "";
    public String link = "";
    public String description = "";
    public String category = "";
    public String iconurl = "";
    public byte[] icon = null;
            
    public ACategoryObj () {    
    }                       
} 

