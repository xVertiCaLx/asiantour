package com.og.app.asiantour;

public class ADeleteObj implements net.rim.device.api.util.Persistable {
    public String guid = "";
    public String publishdate= "";
    public long longpublishdate = 0;
    
    public ADeleteObj () {    
    }                       
} 

