package com.og.app.asiantour;

import java.util.Hashtable;

public class StatusObj {
    public String version_bold = "";
    public String version_storm= "";
    public String version_gemini = "";
    public String serverDateTime= "";

    public String lastBuildDate_index= "";
    public String lastBuildDate_ads= "";
    public String lastBuildDate_weather= "";
    public String lastBuildDate_photos= "";
    public String lastBuildDate_delete= "";

    public Hashtable categorylist = new Hashtable();
    
    public StatusObj   () {    
    }      
                     
} 

