package com.og.app.asiantour;

public class ACategoryList implements net.rim.device.api.util.Persistable {
    public ACategoryObj[] categorylist = null;
    public String lastbuilddate = null;
    
    public ACategoryList () {    
    }                       
} 
