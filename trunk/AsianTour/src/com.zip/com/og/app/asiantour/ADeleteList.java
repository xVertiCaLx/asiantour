package com.og.app.asiantour;

public class ADeleteList implements net.rim.device.api.util.Persistable {
    public ADeleteObj[] deletelist = null;
    public String lastbuilddate = null;

    public ADeleteList () {    
    }                       
} 
