/*
 * DeleteObj.java
 *
 * � <your company here>, 2003-2008
 * Confidential and proprietary.
 */

package com.og.app.asiantour;




/**
 * 
 */
class DeleteObj {
    DeleteObj() {    }
} 
